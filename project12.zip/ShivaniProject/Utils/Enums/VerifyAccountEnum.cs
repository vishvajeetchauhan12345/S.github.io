﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShivaniProject.Utils.Enums
{
    public enum VerifyAccountEnum
    {
        OTPEXPIRED,
        OTPVERIFIED,
        INVALIEDOTP
    }
}
