﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ShivaniProject.Models;
using ShivaniProject.Models.ViewModel;
using ShivaniProject.Repository.Contract;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Security.Claims;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using ShivaniProject.Repository.Services;
using ShivaniProject.Utils.Enums;

namespace ShivaniProject.Controllers
{
    public class UserController : Controller
    {
        private IUser userService;
        public readonly IHostingEnvironment Environment;
        public UserController(IUser user, IHostingEnvironment environment)

        {
            userService = user;
            Environment = environment;
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(SignIn model)
        {
            if (ModelState.IsValid)
            {
                var result = userService.AuthenticateUser(model);
                if (result == AuthoEnum.SUCCESS)
                {
                    var identity = new ClaimsIdentity(new[] {
                    new Claim(ClaimTypes.Name,model.Email)
                    }, CookieAuthenticationDefaults.AuthenticationScheme);

                    var principle = new ClaimsPrincipal(identity);
                    var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principle);

                    return RedirectToAction("Index", "Home");
                }
                else if (result == AuthoEnum.FAILED)
                {
                    ModelState.AddModelError(string.Empty, "invalid Login Credentials !");
                    return View();
                }
                else if (result == AuthoEnum.NOTVERIFIED)
                {
                    ModelState.AddModelError(string.Empty, "Your account is stil not active, Please varify Your account !");
                    return View();
                }
                ModelState.AddModelError(string.Empty, "You are not a valid user !");
                return View();
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Please enter login details !");
                return View();
            }
        }
        public IActionResult Logout()
        {
            var lohin = HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
        public IActionResult UpdateProfile()
        {
            return View();
        }
        public string UploadProfile(IFormFile file)
        {
            var www = Environment.ContentRootPath;
            var fullpath = Path.Combine(www, "wwwroot", "images", file.FileName);

            FileStream stream = new FileStream(fullpath, FileMode.Create);
            file.CopyTo(stream);
            return $"images/{file.FileName}";
        }
        [HttpPost]
        public IActionResult UpdateProfile(string Email)
        {
            var file = Request.Form.Files;
            if (file.Count > 0)
            {
                string path = UploadProfile(file[0]);
                userService.UpdateProfile(Email, path);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "please select file !");
            }
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(SignUp model)
        {
            if (ModelState.IsValid)
            {
                var result = userService.Register(model);
                if (result == null)
                {
                    return RedirectToAction("VerifyUser");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Email is already Exist");
                    return View(model);
                }
            }
            return View();

        }
        public IActionResult VerifyUser()
        {
            return View();
        }
        [HttpPost]
        public IActionResult VerifyUser(string otp)
        {
            if (otp != null)
            {
                var result =userService.VerifyAccount(otp);
                if (result == ShivaniProject.Utils.Enums.VerifyAccountEnum.OTPVERIFIED)
                {
                    return RedirectToAction("Login");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid OTP !");
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Please Enter OTP");
                return View();

            }
            

        }
    }
}