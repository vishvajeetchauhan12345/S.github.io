﻿namespace ShivaniProject.Controllers
{
    internal class VerifyAccountEnum
    {
    }
}