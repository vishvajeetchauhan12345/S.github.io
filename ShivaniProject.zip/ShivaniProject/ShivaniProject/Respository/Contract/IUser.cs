﻿using ShivaniProject.Models.ViewModel;
using ShivaniProject.Utils.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ShivaniProject.Respository.Contract
{
    public interface IUser
    {
        SignUp Register(SignUp model);
        AuthoEnum AuthenticateUser(SignIn model);
        VerifyAccountEnum VerifyAccount(string otp);
        bool UpdateProfile(string Email, string path);
    }
}
